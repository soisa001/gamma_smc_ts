# Predict offspring alleles

You are given independently assembled, haploid parent and offspring DNA sequences
from a synthetic inheritance process. Each calibration pair is separated by one
transmission. Assemblies are error-free, and matching contig identifiers identify
homologous sequence. The same process applies to the new parent assembly. Each scaffold represents a circular DNA molecule; coordinates wrap from its
final base to its first base. Only single-nucleotide changes are generated. Rates in this synthetic system are higher
than typical human germline rates. Predict the offspring's allele on the transmitted
haplotype; diploid segregation is outside this task.

Use calibration_parent.fasta and calibration_offspring.fasta to learn the process.
For each coordinate in queries.tsv, predict the allele in one offspring of
new_parent.fasta. Coordinates are one-based parent-assembly coordinates. Return
predictions.tsv with columns contig, position, p_A, p_C, p_G, p_T, in query order.
Each probability must be finite and nonnegative, and each row must sum to one.
Include the possibility that the offspring allele equals the parent's allele.
Also return the expected total number of changed alleles across the queried sites.
Explain your estimation and validation approach. The offspring outcomes for the
new parent are withheld.
